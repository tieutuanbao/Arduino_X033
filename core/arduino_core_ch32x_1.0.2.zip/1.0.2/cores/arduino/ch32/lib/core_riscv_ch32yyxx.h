#ifndef _CH32YYXX_DEBUG_H_
#define _CH32YYXX_DEBUG_H_

#include "core_riscv.h"


#endif /*   _CH32YYXX_DEBUG_H_ */