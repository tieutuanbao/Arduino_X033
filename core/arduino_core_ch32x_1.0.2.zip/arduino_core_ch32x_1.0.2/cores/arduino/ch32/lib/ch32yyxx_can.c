#ifdef CH32V20x
#include "ch32v20x_can.c"
#endif

#ifdef defined(CH32V30x) || defined(CH32V30x_C)
#include "ch32v30x_can.c"
#endif